﻿CKEDITOR.plugins.setLang("inserthtml","en",{
  inserthtml:
    {
	 title:'Insert Html Code',
	 commonTab:'Info',
	 HelpInfo:'Enter any HTML below to insert at the location of the cursor<br> in the editor.'
	}
});