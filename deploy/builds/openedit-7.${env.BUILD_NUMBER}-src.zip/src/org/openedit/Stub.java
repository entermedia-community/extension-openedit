package org.openedit;

public class Stub {

}
