package org.openedit.html;

import com.openedit.BaseTestCase;

public class HtmlEditTest extends BaseTestCase{

	
	
	public void testNothing(){
		System.out.println("We should add tests");
	}
	
	
}
