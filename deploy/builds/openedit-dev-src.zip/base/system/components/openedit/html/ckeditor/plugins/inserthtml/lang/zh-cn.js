﻿CKEDITOR.plugins.setLang("inserthtml","zh-cn",{
  inserthtml:
    {
	 title:'插入html代码',
	 commonTab:'信息',
	 HelpInfo:'输入要插入的HTML代码 <strong>(在鼠标当前位置)</strong>'
	}
});